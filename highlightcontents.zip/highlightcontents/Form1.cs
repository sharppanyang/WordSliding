﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace highlightcontents
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // 窗体及相关附属资源的初始化配置
            //timer1.Interval = 1000;
            timer1.Interval = 1000;
            label1.Font = new Font("Times New Roman", 30F);
            contextMenuStrip1.Items["全屏显示toolStripMenuItem"].Enabled = false;
            contextMenuStrip1.Items["艾宾浩斯记忆toolStripMenuItem"].Enabled = false;
        }

        string filePath = string.Empty;
        string fileContent = string.Empty;
        string[] words = null;
        int index = 2, count = 0;
        int[,] plansArray = null;
        int[,] scheduleArray = null;
        int start = 1, loop = 1;
        string mode = "normal";
        
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 确认，退出窗体；否则，不退出。
            if (MessageBox.Show("确认退出程序","请确认",MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
            
        }

        private void 读取单词文本ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // 弹出文件打开对话框，过滤txt类型文件，读取文本内容存储到数据结构里
                OpenFileDialog ofd = new OpenFileDialog();

                // 设置ofd 对象的各种属性
                ofd.Title = "读取单词文本";
                ofd.Filter = "txt files (*.txt)|*.txt";
                ofd.FilterIndex = 1;
                ofd.RestoreDirectory = true;
                // 设置ofd 对象的各种属性

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    // 获取已选定的文件
                    filePath = ofd.FileName;

                    // 把文件内容读入流对象中
                    var fileStream = ofd.OpenFile();

                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        label2.Text = "读取数据中，请稍候……";
                        fileContent = reader.ReadToEnd();
                    }
                }

                words = fileContent.Split(
                    new[] { Environment.NewLine },
                    StringSplitOptions.None
                  );

                count = words.Length;

                timer1.Start();
            }
            finally
            {
                contextMenuStrip1.Items["全屏显示toolStripMenuItem"].Enabled = true;
                contextMenuStrip1.Items["艾宾浩斯记忆toolStripMenuItem"].Enabled = true;
            }
            
        }

        private void 全屏显示toolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.label1.Font = new Font("Times New Roman", 85F);
            this.WindowState = FormWindowState.Maximized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            NeedReturnSliding(index, count); //负责切换区间，
            Sliding(index); //负责显示文本
            index++; //切换文本索引
        }

        private void 艾宾浩斯记忆toolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("是否开启艾宾浩斯记忆","请确认",MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                this.mode = "aibinhaosi";
                HardStudying();
            }
        }

        private void HardStudying()
        {
            timer1.Stop();
            AibinhaosiStart(this.count);
            timer1.Start();
        }

        private void AibinhaosiStart(int num)
        {
            // 获取学习计划，返回数组为学习的words索引区间。
            plansArray = GetStudyPlans(num);
            // 对各个学习区间进行排程
            scheduleArray = GetSchedules(plansArray.GetLength(0));
            // 从第一组开始学习,从这里开始 count 不再是位置，而是索引了。！！！！！！！！！！！
            // 位置和索引的变量名请不要混用。！！！！！！！！！
            this.index = plansArray[0, 0];
            this.count = plansArray[0, 1];
        }

        private static int[,] GetStudyPlans(int num)
        {
            int capacity = 300;
            //int capacity = 5;
            int rows = Convert.ToInt32(Math.Ceiling(num / (double)capacity));
            int columns = 2;
            int leftNums = num - (rows-1) * capacity;
            int begin=2, step1 = 1, step2 = capacity - step1;
            int[,] boundaries = new int[rows, columns];
            boundaries[0, 0] = begin - capacity;
            boundaries[0, 1] = 1;
            for (int i = 0; i < boundaries.GetLength(0); i++)
            {
                for (int j = 0; j < boundaries.GetLength(1); j = j + 2)
                {
                    if (i == 0)
                    {
                        boundaries[0, 0] = boundaries[0, 1] + step1;
                        boundaries[0, 1] = boundaries[0, 0] + step2;
                    }
                    else if (i == boundaries.GetLength(0) - 1)
                    {
                        boundaries[i, j] = boundaries[i - 1, j + 1] + step1;
                        boundaries[i, j + 1] = boundaries[i, j] + leftNums;
                    }
                    else
                    {
                        boundaries[i, j] = boundaries[i - 1, j + 1] + step1;
                        boundaries[i, j + 1] = boundaries[i, j] + step2;
                    }
                }
            }
            return boundaries;
        }

        private static int[,] GetSchedules(int num)
        {
            int rows = num * 2;
            int columns = num;
            int[,] returnArray = new int[rows, columns];

            for (int i = 0; i < rows; i++)
            {
                if (i < columns) //降序梯子，第 0 到 columns - 1行
                {
                    int currentLineNum = i + 1;
                    for (int j = 0; j < columns; j++)
                    {
                        returnArray[i, j] = currentLineNum;
                        if (currentLineNum > 0)
                        {
                            currentLineNum--;
                        }
                    }
                }
                else // 升序梯子，第 columns 到 rows - 1行。
                {
                    int currentLineNum = rows - i;
                    for (int j = 0; j < i - columns + 1; j++)
                    {
                        returnArray[i, j] = currentLineNum;
                        if ( columns - currentLineNum > 0)
                        {
                            currentLineNum++;
                        }
                    }
                }
            }
            return returnArray;
        }

        private void Sliding(int index)
        {
            label2.Text = string.Format("当前第{0}个:共{1}个", index - 1, count - 1);
            label1.Text = words[index];           
        }
        
        private void NeedReturnSliding(int index, int count)
        {
            // 到达区间终点，切换到下一个区间
            if (index > count && "normal".Equals(this.mode)) //normal模式下切换区间
            {
                this.index = 2;
                this.count = words.Length;
            }
            
            if ( index > count && "aibinhaosi".Equals(this.mode)) //艾宾浩斯记忆模式下切换区间
            {
                if (this.loop >= 0)
                {
                    this.index = plansArray[scheduleArray[this.start, this.start - this.loop] - 1, 0];
                    this.count = plansArray[scheduleArray[this.start, this.start - this.loop] - 1, 1];
                    if (this.loop == 0)
                    {
                        if (this.start == plansArray.GetLength(0) * 2)
                        {
                            this.start = 0;
                        }
                        this.start += 1;
                        this.loop = this.start + 1;
                    }
                    this.loop -= 1;
                }
            }
        }
    }
}
